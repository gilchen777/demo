package poc.marketingproduct.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import poc.marketingproduct.util.json.JsonUtil;
import poc.marketingproduct.util.logging.AppLogger;

@WebServlet("/api/clrp-validate")
public class CLRPValidator extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final AppLogger logger = AppLogger.getLogger(CLRPValidator.class);
	private static final String COOKIE_GEOLOC = "geoloc";
	private static final String COOKIE_ROLEPRODUCT = "ruleproduct";

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doWork(request, response);
	}

	private void doWork(HttpServletRequest request, HttpServletResponse response) throws IOException {
		StandResponseJson reval = new StandResponseJson();
		try {
			reval.setData(getCLRPFromCookie(request));
			reval.setStatus("success");
			// if (request.getParameter("check") != null) {
			//
			// }
		} catch (Exception e) {
			logger.error("error!", e);
			reval.setData(null);
			reval.setStatus("error");
			reval.setMessage(e.getMessage());
		}
		try (PrintWriter out = response.getWriter()) {
			response.setContentType("application/json");
			response.setCharacterEncoding("utf-8");
			out.print(JsonUtil.toJson(reval));
			out.flush();
		} catch (Exception e) {
			logger.error("Unknow error!", e);
		}
	}

	private CLRP getCLRPFromCookie(HttpServletRequest request) {
		Cookie[] cookieList = request.getCookies();
		CLRP reval = new CLRP();
		for (Cookie ck : cookieList) {
			// geoloc=au:en_gb
			if (COOKIE_GEOLOC.equals(ck.getName())) {
				String[] twoString = ck.getValue().split(":");
				reval.setC(twoString[0]);
				reval.setL(twoString[1]);
			} else if (COOKIE_ROLEPRODUCT.equals(ck.getName())) {
				String[] twoString = ck.getValue().split(":");
				reval.setR(twoString[0]);
				reval.setP(twoString[1]);
			}
		}

		return reval;
	}

}

package poc.marketingproduct.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import poc.marketingproduct.util.logging.AppLogger;

@WebServlet("/*")
public class DefaultAction extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static AppLogger log = AppLogger.getLogger(DefaultAction.class);

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		// Writing response to display on page
		
//		boolean popupFlag = false;
//		boolean showBackGroundFlag = false;
		
		String requestURL = req.getRequestURI();
		log.debug("Inner servlet for:" + requestURL);
		out.write("<html><head><title>Default Page</title>");
		//
		out.write("<script src=\"/js/jquery-3.4.1.min.js\"></script>");
		out.write("<script src=\"/js/app.js\"></script>");
		out.write("</head>");
		
		out.write("<body>");
		out.write("<div id=\"main\" style=\"display:none;\">");
		out.write("<h2> Comming URL is: " + requestURL + "</h2>");
		out.write("<img src=\"/images/insights-using-etfs.png\" class=\"default-image\">");
		//images\insights-using-etfs.png
		//out.write("<div id=\"status-flags\"  data-popup-flag=\"" + popupFlag +  "\" data-show-background-flag=\"" + showBackGroundFlag +  "\" > Flags in data-* </div>");
		out.write("</div>");
		out.write("</body>");
		out.write("</html>");
	}
}
package poc.marketingproduct.web;

import java.io.Serializable;

public class StandResponseJson implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3925736043250479596L;
	
	private String status; //e.g "success", "error"
	private String message;//
	private Object data;//the json
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}

}

package poc.marketingproduct.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import poc.marketingproduct.util.json.JsonUtil;
import poc.marketingproduct.util.logging.AppLogger;

@WebServlet("/api/clrp-cookie")
public class CLRPCookieAction extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String COOKIE_GEOLOC = "geoloc";
	private static final String COOKIE_ROLEPRODUCT = "ruleproduct";
	private static final AppLogger logger = AppLogger.getLogger(CLRPCookieAction.class);
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doWork(request, response);
	}

	private void doWork(HttpServletRequest request, HttpServletResponse response) throws IOException {
		StandResponseJson reval = new StandResponseJson();
		try {
			Object data = request.getAttribute("data");
			if (data != null) {
				CLRP clrp = JsonUtil.fromJson(data.toString(), CLRP.class);
				saveCookie(COOKIE_GEOLOC, clrp.getC()+":"+clrp.getL(), 60*60*24*356, response);
				saveCookie(COOKIE_ROLEPRODUCT, clrp.getR()+":"+clrp.getP(), 60*60*24*3, response);
				reval.setStatus("success");
			} else {
				reval.setStatus("error");
				reval.setMessage("no CLRP in the comming request");
			}
		} catch (Exception e) {
			logger.error("error!", e);
			reval.setData(null);
			reval.setStatus("error");
			reval.setMessage(e.getMessage());
		} 
		try (PrintWriter out = response.getWriter()) {
			response.setContentType("application/json");
			response.setCharacterEncoding("utf-8");
			out.print(JsonUtil.toJson(reval));
			out.flush();
		} catch (Exception e) {
			logger.error("Unknow error!", e);
		}
	}
	
	private void saveCookie(String name, String value, int maxAge, HttpServletResponse response) {
		Cookie cookie = new Cookie(name, value);
		cookie.setHttpOnly(true);
		cookie.setMaxAge(maxAge); //1 hour
		response.addCookie(cookie);
	}

}
